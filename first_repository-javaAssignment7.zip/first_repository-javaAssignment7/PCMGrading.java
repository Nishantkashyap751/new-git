import java.util.*;
class PCMGrading{
    static char grade(double a){
        if(a>=90) return 'A';
        if(a>=80) return 'B';
        if(a>=70) return 'C';
        if(a>=60) return 'D';
        return 'F';
    }
    public static void main(String[]x){
        Scanner s=new Scanner(System.in);
        int n=s.nextInt();
        for(int i=0;i<n;i++){
            double p=s.nextDouble(),c=s.nextDouble(),m=s.nextDouble();
            double avg=(p+c+m)/3;
            System.out.println(grade(avg));
        }
    }
}