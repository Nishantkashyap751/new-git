import java.util.*;
class AnagramCheck{
    static boolean ana(String a,String b){
        if(a.length()!=b.length()) return false;
        int[] f=new int[256];
        for(int i=0;i<a.length();i++){f[a.charAt(i)]++;f[b.charAt(i)]--;}
        for(int i=0;i<256;i++) if(f[i]!=0) return false;
        return true;
    }
    public static void main(String[]x){
        Scanner s=new Scanner(System.in);
        String a=s.next(),b=s.next();
        System.out.println(ana(a,b));
    }
}