import java.util.*;
class StringToCharArrayCompare {
    static char[] arr(String s) {
        char[]r=new char[s.length()];
        for(int i=0;
        i<s.length();
        i++)r[i]=s.charAt(i);
        return r;
        
    }
    static boolean cmp(char[]a,char[]b) {
        if(a.length!=b.length)return false;
        for(int i=0;
        i<a.length;
        i++)if(a[i]!=b[i])return false;
        return true;
        
    }
    public static void main(String[]x) {
        Scanner s=new Scanner(System.in);
        String a=s.next();
        System.out.println(cmp(arr(a),a.toCharArray()));
        
    }
    
}