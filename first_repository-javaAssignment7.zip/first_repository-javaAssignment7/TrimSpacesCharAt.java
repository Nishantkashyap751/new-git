import java.util.*;
class TrimSpacesCharAt{
    static int[] idx(String s){
        int i=0,j=s.length()-1;
        while(i<=j && s.charAt(i)==' ') i++;
        while(j>=i && s.charAt(j)==' ') j--;
        return new int[]{i,j+1};
    }
    static String sub(String s,int a,int b){
        String r="";
        for(int i=a;i<b;i++) r+=s.charAt(i);
        return r;
    }
    static boolean cmp(String a,String b){
        if(a.length()!=b.length()) return false;
        for(int i=0;i<a.length();i++) if(a.charAt(i)!=b.charAt(i)) return false;
        return true;
    }
    public static void main(String[]x){
        Scanner s=new Scanner(System.in);
        String t=s.nextLine();
        int[] p=idx(t);
        String u=sub(t,p[0],p[1]);
        String v=t.trim();
        System.out.println(u);
        System.out.println(v);
        System.out.println(cmp(u,v));
    }
}