import java.util.*;
class IllegalArgumentDemo {
    static void gen(String s) {
        System.out.println(s.substring(5,2));
        
    }
    static void h(String s) {
        try {
            System.out.println(s.substring(5,2));
            
        }
        catch(IllegalArgumentException e) {
            System.out.println("Caught");
            
        }
        
    }
    public static void main(String[]x) {
        Scanner s=new Scanner(System.in);
        String a=s.next();
        h(a);
        
    }
    
}