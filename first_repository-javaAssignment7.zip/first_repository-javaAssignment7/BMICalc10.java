import java.util.*;
class BMICalc10{
    public static void main(String[]x){
        Scanner s=new Scanner(System.in);
        for(int i=0;i<10;i++){
            double w=s.nextDouble(),h=s.nextDouble();
            double bmi=w/(h*h);
            System.out.println(bmi);
        }
    }
}