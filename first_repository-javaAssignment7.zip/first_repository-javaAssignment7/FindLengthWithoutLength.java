import java.util.*;
class FindLengthWithoutLength {
    static int len(String s) {
        int i=0;
        try {
            while(true) {
                s.charAt(i);
                i++;
                
            }
            
        }
        catch(Exception e) {
            
        }
        return i;
        
    }
    public static void main(String[]x) {
        Scanner s=new Scanner(System.in);
        String a=s.next();
        System.out.println(len(a));
        System.out.println(a.length());
        
    }
    
}