import java.util.*;
class StringIndexOutOfBoundsDemo {
    static void gen(String s) {
        System.out.println(s.charAt(s.length()));
        
    }
    static void h(String s) {
        try {
            System.out.println(s.charAt(s.length()));
            
        }
        catch(StringIndexOutOfBoundsException e) {
            System.out.println("Caught");
            
        }
        
    }
    public static void main(String[]x) {
        Scanner s=new Scanner(System.in);
        String a=s.next();
        h(a);
        
    }
    
}