class NullPointerDemo {
    static void gen() {
        String s=null;
        System.out.println(s.length());
        
    }
    static void h() {
        try {
            String s=null;
            System.out.println(s.length());
            
        }
        catch(NullPointerException e) {
            System.out.println("Caught");
            
        }
        
    }
    public static void main(String[]x) {
        h();
        
    }
    
}