import java.util.*;
class VotingEligibility10{
    static boolean can(int a){
        if(a<0) return false;
        return a>=18;
    }
    public static void main(String[]x){
        Scanner s=new Scanner(System.in);
        int[] a=new int[10];
        for(int i=0;i<10;i++) a[i]=s.nextInt();
        String[][] r=new String[10][2];
        for(int i=0;i<10;i++){
            r[i][0]=String.valueOf(a[i]);
            r[i][1]=String.valueOf(can(a[i]));
        }
        System.out.println("Age	CanVote");
        for(int i=0;i<10;i++) System.out.println(r[i][0] + "\t" + r[i][1]);
    }
}