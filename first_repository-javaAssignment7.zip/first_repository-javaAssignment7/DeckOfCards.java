import java.util.*;
public class DeckOfCards {
    static String[] initializeDeck() {
        String[] suits={"Hearts","Diamonds","Clubs","Spades"};
        String[] ranks={"2","3","4","5","6","7","8","9","10","Jack","Queen","King","Ace"};
        String[] deck=new String[suits.length*ranks.length];
        int index=0;
        for(String s:suits) {
            for(String r:ranks) {
                deck[index++]=r+" of "+s;
            }
        }
        return deck;
    }
    static void shuffleDeck(String[] deck) {
        Random rand=new Random();
        for(int i=0;i<deck.length;i++) {
            int randomCardNumber=i+rand.nextInt(deck.length-i);
            String temp=deck[i];
            deck[i]=deck[randomCardNumber];
            deck[randomCardNumber]=temp;
        }
    }
    static String[][] distributeCards(String[] deck,int players,int cardsPerPlayer) {
        String[][] hands=new String[players][cardsPerPlayer];
        int index=0;
        for(int i=0;i<players;i++) {
            for(int j=0;j<cardsPerPlayer;j++) {
                hands[i][j]=deck[index++];
            }
        }
        return hands;
    }
    static void printHands(String[][] hands) {
        for(int i=0;i<hands.length;i++) {
            System.out.println("Player "+(i+1)+":");
            for(int j=0;j<hands[i].length;j++) {
                System.out.println(hands[i][j]);
            }
            System.out.println();
        }
    }
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int players=sc.nextInt();
        int cardsPerPlayer=sc.nextInt();
        String[] deck=initializeDeck();
        shuffleDeck(deck);
        if(players*cardsPerPlayer>deck.length) {
            System.out.println("Not enough cards.");
            return;
        }
        String[][] hands=distributeCards(deck,players,cardsPerPlayer);
        printHands(hands);
    }
}
