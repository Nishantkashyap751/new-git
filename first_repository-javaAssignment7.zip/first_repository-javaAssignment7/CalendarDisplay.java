import java.util.*;
public class CalendarDisplay {
    static String getMonthName(int m) {
        String[] months = {"January","February","March","April","May","June","July","August","September","October","November","December"};
        return months[m-1];
    }
    static int getDaysInMonth(int m, int y) {
        int[] days = {31,28,31,30,31,30,31,31,30,31,30,31};
        if(m==2 && isLeapYear(y)) return 29;
        return days[m-1];
    }
    static boolean isLeapYear(int y) {
        if(y%400==0 || (y%4==0 && y%100!=0)) return true;
        return false;
    }
    static int getFirstDay(int d,int m,int y) {
        int y0=y-(14-m)/12;
        int x=y0+y0/4-y0/100+y0/400;
        int m0=m+12*((14-m)/12)-2;
        int d0=(d+x+31*m0/12)%7;
        return d0;
    }
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int m=sc.nextInt();
        int y=sc.nextInt();
        System.out.println("   "+getMonthName(m)+" "+y);
        System.out.println("Sun Mon Tue Wed Thu Fri Sat");
        int days=getDaysInMonth(m,y);
        int first=getFirstDay(1,m,y);
        for(int i=0;i<first;i++) System.out.print("    ");
        for(int day=1;day<=days;day++) {
            System.out.printf("%3d ",day);
            if((day+first)%7==0) System.out.println();
        }
    }
}
