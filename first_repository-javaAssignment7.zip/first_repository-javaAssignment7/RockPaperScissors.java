import java.util.*;
class RockPaperScissors{
    static int pickComp(){
        double d=Math.random();
        if(d<1.0/3) return 0;
        if(d<2.0/3) return 1;
        return 2;
    }
    static String name(int v){return v==0?"rock":v==1?"paper":"scissors";}
    static int judge(int u,int c){
        if(u==c) return 0;
        if(u==0 && c==2) return 1;
        if(u==1 && c==0) return 1;
        if(u==2 && c==1) return 1;
        return -1;
    }
    public static void main(String[]x){
        Scanner s=new Scanner(System.in);
        int n=s.nextInt();
        int uw=0,cw=0,t=0;
        for(int i=1;i<=n;i++){
            String in=s.next();
            int u=in.equals("rock")?0:in.equals("paper")?1:2;
            int c=pickComp();
            int r=judge(u,c);
            String res=r==1?"User":r==0?"Tie":"Comp";
            if(r==1) uw++; else if(r==-1) cw++; else t++;
            System.out.println(i+"\t"+name(u)+"\t"+name(c)+"\t"+res);
        }
        System.out.println("Summary:");
        System.out.println("UserWins:\t"+uw);
        System.out.println("CompWins:\t"+cw);
        System.out.println("Ties:\t"+t);
        double tot=n;
        System.out.println("User%:\t"+Math.round((uw/tot*100)*100.0)/100.0);
        System.out.println("Comp%:\t"+Math.round((cw/tot*100)*100.0)/100.0);
    }
}