import java.util.*;
class ArrayIndexOutOfBoundsDemo {
    static void gen(String[]a) {
        System.out.println(a[a.length]);
        
    }
    static void h(String[]a) {
        try {
            System.out.println(a[a.length]);
            
        }
        catch(ArrayIndexOutOfBoundsException e) {
            System.out.println("Caught");
            
        }
        
    }
    public static void main(String[]x) {
        Scanner s=new Scanner(System.in);
        int n=s.nextInt();
        String[]a=new String[n];
        for(int i=0;
        i<n;
        i++)a[i]=s.next();
        h(a);
        
    }
    
}