import java.util.*;
class PalindromeCheck{
    static boolean pal(String s){
        int i=0,j=s.length()-1;
        while(i<j){
            if(s.charAt(i)!=s.charAt(j)) return false;
            i++;j--;
        }
        return true;
    }
    public static void main(String[]x){
        Scanner s=new Scanner(System.in);
        String a=s.nextLine();
        System.out.println(pal(a));
    }
}