import java.util.*;
class SubstringCompare {
    static String sub(String s,int i,int j) {
        String r="";
        for(int k=i;
        k<j;
        k++)r+=s.charAt(k);
        return r;
        
    }
    public static void main(String[]x) {
        Scanner s=new Scanner(System.in);
        String a=s.next();
        int i=s.nextInt(),j=s.nextInt();
        String u=sub(a,i,j),v=a.substring(i,j);
        System.out.println(u);
        System.out.println(v);
        System.out.println(u.equals(v));
        
    }
    
}