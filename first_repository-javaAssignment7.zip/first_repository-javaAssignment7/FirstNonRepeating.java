import java.util.*;
class FirstNonRepeating{
    public static void main(String[]x){
        Scanner s=new Scanner(System.in);
        String a=s.nextLine();
        int[] f=new int[256];
        for(int i=0;i<a.length();i++) f[a.charAt(i)]++;
        for(int i=0;i<a.length();i++){
            if(f[a.charAt(i)]==1){
                System.out.println(a.charAt(i));
                return;
            }
        }
    }
}