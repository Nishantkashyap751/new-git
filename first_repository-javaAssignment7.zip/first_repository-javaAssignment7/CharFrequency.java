import java.util.*;
class CharFrequency{
    public static void main(String[]x){
        Scanner s=new Scanner(System.in);
        String a=s.nextLine();
        int[] f=new int[256];
        for(int i=0;i<a.length();i++) f[a.charAt(i)]++;
        for(int i=0;i<256;i++) if(f[i]>0) System.out.println((char)i+" "+f[i]);
    }
}