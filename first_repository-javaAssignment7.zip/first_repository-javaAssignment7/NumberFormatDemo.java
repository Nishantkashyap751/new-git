import java.util.*;
class NumberFormatDemo {
    static void gen(String s) {
        int x=Integer.parseInt(s);
        System.out.println(x);
        
    }
    static void h(String s) {
        try {
            int x=Integer.parseInt(s);
            System.out.println(x);
            
        }
        catch(NumberFormatException e) {
            System.out.println("Caught");
            
        }
        
    }
    public static void main(String[]x) {
        Scanner s=new Scanner(System.in);
        String a=s.next();
        h(a);
        
    }
    
}