import java.util.*;
class UniqueChars{
    public static void main(String[]x){
        Scanner s=new Scanner(System.in);
        String a=s.nextLine();
        boolean[] seen=new boolean[256];
        for(int i=0;i<a.length();i++){
            char c=a.charAt(i);
            if(!seen[c]){
                System.out.print(c);
                seen[c]=true;
            }
        }
    }
}