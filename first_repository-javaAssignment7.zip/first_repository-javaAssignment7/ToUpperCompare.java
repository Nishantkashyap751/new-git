import java.util.*;
class ToUpperCompare {
    static String up(String s) {
        String r="";
        for(int i=0;
        i<s.length();
        i++) {
            char c=s.charAt(i);
            r+=(c>='a'&&c<='z')?(char)(c-32):c;
            
        }
        return r;
        
    }
    static boolean cmp(String a,String b) {
        if(a.length()!=b.length())return false;
        for(int i=0;
        i<a.length();
        i++)if(a.charAt(i)!=b.charAt(i))return false;
        return true;
        
    }
    public static void main(String[]x) {
        Scanner s=new Scanner(System.in);
        String a=s.nextLine(),b=up(a),c=a.toUpperCase();
        System.out.println(b);
        System.out.println(c);
        System.out.println(cmp(b,c));
        
    }
    
}