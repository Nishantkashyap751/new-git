import java.util.*;
class VowelsConsonantsCount {
    static boolean v(char c) {
        c=Character.toLowerCase(c);
        return"aeiou".indexOf(c)!=-1;
        
    }
    public static void main(String[]x) {
        Scanner s=new Scanner(System.in);
        String a=s.nextLine();
        int v=0,c=0;
        for(int i=0;
        i<a.length();
        i++) {
            char ch=a.charAt(i);
            if(Character.isLetter(ch)) {
                if(v(ch))v++;
                else c++;
                
            }
            
        }
        System.out.println(v+" "+c);
        
    }
    
}